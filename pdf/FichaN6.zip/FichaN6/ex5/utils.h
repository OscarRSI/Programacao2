/* 
 * File:   utils.h
 * Author: Oscar
 *
 * Created on 23 de Novembro de 2017, 12:25
 */

#ifndef UTILS_H
#define UTILS_H
#define STRING_MAX 15

void clean_buffer();
int lerString(char *string, int max);

#endif /* UTILS_H */

