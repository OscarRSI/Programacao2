/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   utils.h
 * Author: Oscar
 *
 * Created on 23 de Novembro de 2017, 10:42
 */

#ifndef UTILS_H
#define UTILS_H
#define STRING_MAX 15

void clean_buffer();
int lerString(char *string, int max);

#endif /* UTILS_H */

