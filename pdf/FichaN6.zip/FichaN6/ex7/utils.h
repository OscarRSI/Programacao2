/* 
 * File:   utils.h
 * Author: Oscar
 *
 * Created on 24 de Novembro de 2017, 17:48
 */

#ifndef UTILS_H
#define UTILS_H
#define STRING_MAX 50

void clean_buffer();
int lerString(char *string, int max);
void countchar(char a[], int tamanho);


#endif /* UTILS_H */

