/* 
 * File:   utils.h
 * Author: Oscar
 *
 * Created on 23 de Novembro de 2017, 14:23
 */

#ifndef UTILS_H
#define UTILS_H

#define STRING_MAX 15

void clean_buffer();
int lerString(char *string, int max);
char lerChar (char carater);
void CountChar(char a[], char carater);

#endif /* UTILS_H */

