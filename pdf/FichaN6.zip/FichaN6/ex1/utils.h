/* 
 * File:   utils.h
 * Author: Oscar
 *
 * Created on 24 de Novembro de 2017, 19:02
 */

#ifndef UTILS_H
#define UTILS_H

void clean_buffer();
int lerstring ( char *string, int max);

#endif /* UTILS_H */

