/* 
 * File:   main.c
 * Author: Oscar
 *
 * Created on 20 de Novembro de 2017, 18:00
 */

#include <stdio.h>
#include <stdlib.h>
#include  "utils.h"

int main(int argc, char** argv) {

    return (EXIT_SUCCESS);
}

