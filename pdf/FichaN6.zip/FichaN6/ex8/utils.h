/* 
 * File:   utils.h
 * Author: Oscar
 *
 * Created on 24 de Novembro de 2017, 18:20
 */

#ifndef UTILS_H
#define UTILS_H

#define STRING_MAX 50

void clean_buffer();
int lerString(char *string, int max);


#endif /* UTILS_H */

