/* 
 * File:   main.c
 * Author: Oscar
 *
 * Created on 26 de Outubro de 2017, 19:52
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) 
{
    int Num;
    
    for(Num=1; Num <= 100; ++Num)
    {
        printf("%d",Num);
    }
    return (0);
}

