/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   headerEX7.h
 * Author: Oscar
 *
 * Created on 9 de Novembro de 2017, 21:38
 */

#ifndef HEADEREX7_H
#define HEADEREX7_H

#define MAX 100
#define MIN 1
#define AST '*'

int lerinteiro(int minimo, int maximo);

#endif /* HEADEREX7_H */

