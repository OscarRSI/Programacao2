/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   headerEX8.h
 * Author: Oscar
 *
 * Created on 9 de Novembro de 2017, 21:43
 */

#ifndef HEADEREX8_H
#define HEADEREX8_H

#define MAX 20
#define MIN 0
#define AST '*'

int lerinteiro(int minimo, int maximo);

#endif /* HEADEREX8_H */

