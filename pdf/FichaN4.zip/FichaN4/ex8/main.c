
/* 
 * File:   main.c
 * Author: Oscar
 *
 * Created on 9 de Novembro de 2017, 21:08
 */

#include <stdio.h>
#include HEADEREX8_H

int main(int argc, char** argv) {

    int a, minimo, maximo;


    a = lerinteiro(MIN, MAX);
    caracter(a);

    return 0;
}
